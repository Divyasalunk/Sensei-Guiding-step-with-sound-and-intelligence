import datetime
import pyautogui
import pyttsx3
import speech_recognition
import requests
from bs4 import BeautifulSoup
import wmi  # Added for brightness control

# Initialize the text-to-speech engine
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[1].id)
rate = engine.setProperty("rate", 170)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def takeCommand(timeout=10):
    r = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        print("Listening to User.....")
        r.pause_threshold = 1
        r.energy_threshold = 300
        try:
            audio = r.listen(source, timeout=timeout)  # Wait for up to 10 seconds for user input
            print("Understanding..")
            query = r.recognize_google(audio, language='en-in')
            print(f"You Said: {query}\n")
            return query.lower()
        except Exception as e:
            print("No response or error. Proceeding with 'None'.")
            return "none"


# Function to generate a letter
def generate_letter(recipient_name, reason, sender_name, sender_designation):
    letter = f"""
    Dear {recipient_name},

    I hope this letter finds you well. I am writing to you because i want {reason}.
    I look forward to hearing from you soon.

    Best regards,
    {sender_name}
    {sender_designation}
    """
    return letter

# Function to set brightness
def set_brightness(level):
    try:
        # Initialize WMI object
        wmi_service = wmi.WMI(namespace='wmi')
        brightness_methods = wmi_service.WmiMonitorBrightnessMethods()[0]
        
        # Set brightness level (0 to 100)
        brightness_methods.WmiSetBrightness(level, 0)  
        speak(f"Brightness set to {level} percent")
    except Exception as e:
        speak("Sorry, I couldn't adjust the brightness.")

# Main program loop
if __name__ == "__main__":

    while True:
        query = takeCommand().lower()

        if "wake up" in query:
            from GreetMe import greetMe
            greetMe()

            while True:
                query = takeCommand().lower()
                if "go to sleep" in query:
                    speak("Ok sir, You can call me anytime")
                    break 

                elif "set brightness to" in query:
                    try:
                        # Extract the brightness level from the command
                        level = int([int(s) for s in query.split() if s.isdigit()]
                                    [0])
                        
                        # Validate level is within the range (0-100)
                        if 0 <= level <= 100:
                            set_brightness(level)
                        else:
                            speak("Please specify a brightness level between 0 and 100.")
                    except ValueError:
                        speak("I couldn't understand the brightness level. Please try again.")

                elif "write a letter" in query:
                    # Ask for recipient's name
                    speak("To whom should I address the letter?")
                    recipient_name = takeCommand(timeout=10)

                    if recipient_name == "none":
                        speak("I didn't catch the name. Please try again.")
                    else:
                        # Ask for the reason
                        speak(f"What's the reason for writing the letter to {recipient_name}?")
                        reason = takeCommand(timeout=10)

                        if reason == "none":
                            speak("I didn't catch the reason. Please try again.")
                        else:
                            # Ask for sender's name
                            speak("Please tell me your name.")
                            sender_name = takeCommand(timeout=10)

                        if sender_name == "none":
                                speak("I didn't catch your name. Please try again.")
                        else:
                         # Ask for sender's designation
                                speak("Please tell me your designation.")
                        sender_designation = takeCommand(timeout=10)

                        if sender_designation == "none":
                                    speak("I didn't catch your designation. Please try again.")
                        else:
                                    # Generate the letter
                                    letter = generate_letter(recipient_name, reason, sender_name, sender_designation)
                                    print(letter)
                                    speak("Here is your letter.")
                                    speak(letter)

               
                elif "hello" in query:
                    speak("Hello sir, how are you?")
                elif "i am fine" in query:
                    speak("That's great, sir")
                elif "how are you" in query:
                    speak("Perfectly awesome, sir")
                elif "thank you very much" in query:
                    speak("You are welcome, sir")

                # Add other commands and functionality as necessary
                elif "pause" in query:
                    pyautogui.press("k")
                    speak("Video paused")
                elif "play" in query:
                    pyautogui.press("k")
                    speak("Video played")
                elif "mute" in query:
                    pyautogui.press("m")
                    speak("Video muted")

                elif "volume up" in query:
                    from keyboard import volumeup
                    speak("Turning volume up, sir")
                    volumeup()
                elif "volume down" in query:
                    from keyboard import volumedown
                    speak("Turning volume down, sir")
                    volumedown()

                elif "open" in query:
                    from Dictapp import openappweb
                    openappweb(query)
                elif "close" in query:
                    from Dictapp import closeappweb
                    closeappweb(query)

                elif "google" in query:
                    from SearchNow import searchGoogle
                    searchGoogle(query)
                elif "youtube" in query:
                    from SearchNow import searchYoutube
                    searchYoutube(query)
                elif "wikipedia" in query:
                    from SearchNow import searchWikipedia
                    searchWikipedia(query)

                elif "the time" in query:
                     strTime = datetime.datetime.now().strftime("%H:%M")
                     speak(f"Sir, the time is {strTime}")
                 

                elif "close" in query:
                      speak("Going to sleep, sir")
                      exit()
