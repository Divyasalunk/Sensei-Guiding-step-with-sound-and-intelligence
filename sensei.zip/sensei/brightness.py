# brightness.py
import screen_brightness_control as sbc
from time import sleep

def set_brightness_to(percent, delay=0.1):
    """Set screen brightness to a specific percentage."""
    try:
        percent = max(0, min(100, percent))  
        sbc.set_brightness(percent)
        sleep(delay)
    except Exception as e:
        print(f"Error setting brightness: {e}")
